<template>
  <div class="accordion-list">
    <slot></slot>
  </div>
</template>
<script>
  export default {}
</script>