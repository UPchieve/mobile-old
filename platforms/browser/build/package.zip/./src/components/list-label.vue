<template>
  <div class="list-block-label">
    <slot></slot>
  </div>
</template>
<script>
  export default {}
</script>