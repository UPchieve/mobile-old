<template>
  <f7-page toolbar-fixed>
    <f7-navbar>
      <f7-nav-left>
        <f7-link icon="icon-bars" open-panel="left"></f7-link>
      </f7-nav-left>
      <f7-nav-center sliding>Hello World</f7-nav-center>
      <f7-nav-right>
        <f7-link icon="icon-bars" open-panel="right"></f7-link>
      </f7-nav-right>
    </f7-navbar>
    <f7-toolbar>
      <f7-link>Left</f7-link>
      <f7-link>Right</f7-link>
    </f7-toolbar>

    <f7-list>
      <f7-list-item title="Accordion" link="/accordion/"></f7-list-item>
      <f7-list-item title="Calendar" link="/calendar/"></f7-list-item>
      <f7-list-item title="Cards" link="/cards/"></f7-list-item>
      <f7-list-item title="Chips" link="/chips/"></f7-list-item>
      <f7-list-item title="Contacts" link="/contacts/"></f7-list-item>
      <f7-list-item title="Content Block" link="/content-block/"></f7-list-item>
      <f7-list-item title="Data Table" link="/data-table/"></f7-list-item>
      <f7-list-item title="FAB" link="/fab/"></f7-list-item>
      <f7-list-item title="FAB Speed Dial" link="/fab-dial/"></f7-list-item>
      <f7-list-item title="Forms" link="/forms/"></f7-list-item>
      <f7-list-item title="Grid" link="/grid/"></f7-list-item>
      <f7-list-item title="Infinite Scroll" link="/infinite/"></f7-list-item>
      <f7-list-item title="Lists" link="/lists/"></f7-list-item>
      <f7-list-item title="Login Screen" link="/login-screen/"></f7-list-item>
      <f7-list-item title="Messages" link="/messages/"></f7-list-item>
      <f7-list-item title="Modals" link="/modals/"></f7-list-item>
      <f7-list-item title="Navbars & Toolbars" link="/bars/"></f7-list-item>
      <f7-list-item title="Photo Browser" link="/photo-browser/"></f7-list-item>
      <f7-list-item title="Preloader" link="/preloader/"></f7-list-item>
      <f7-list-item title="Progress Bar" link="/progressbar/"></f7-list-item>
      <f7-list-item title="Pull To Refresh" link="/pull-to-refresh/"></f7-list-item>
      <f7-list-item title="Searchbar" link="/searchbar/"></f7-list-item>
      <f7-list-item title="Smart Select" link="/smart-select/"></f7-list-item>
      <f7-list-item title="Sortable" link="/sortable/"></f7-list-item>
      <f7-list-item title="Swipeout" link="/swipeout/"></f7-list-item>
      <f7-list-item title="Swiper" link="/swiper/"></f7-list-item>
      <f7-list-item title="Tabs" link="/tabs/"></f7-list-item>
      <f7-list-item title="Tabs Swipeable" link="/tabs-swipeable/"></f7-list-item>
      <f7-list-item title="Timeline Vertical" link="/timeline-vertical/"></f7-list-item>
      <f7-list-item title="Timeline Horizontal" link="/timeline-horizontal/"></f7-list-item>
      <f7-list-item title="Timeline Calendar" link="/timeline-calendar/"></f7-list-item>
      <f7-list-item title="Virtual List" link="/virtual-list/"></f7-list-item>
      <f7-list-item title="Virtual List with Vue" link="/virtual-list-vue/"></f7-list-item>
    </f7-list>
    <f7-list>
      <f7-list-item title="Dynamic Route" link="/user/45/posts/28/?sort=first#opened"></f7-list-item>
      <f7-list-item title="Nested Routes" link="/nested-routes/"></f7-list-item>
      <f7-list-item title="Data Binding" link="/data-binding/"></f7-list-item>
    </f7-list>
  </f7-page>
</template>
<script>
  export default {}
</script>
