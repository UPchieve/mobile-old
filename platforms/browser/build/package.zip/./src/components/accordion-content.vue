<template>
  <div class="accordion-item-content">
    <slot></slot>
  </div>
</template>
<script>
  export default {}
</script>