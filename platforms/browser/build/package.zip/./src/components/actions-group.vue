<template>
  <div class="actions-modal-group">
    <slot></slot>
  </div>
</template>
<script>
  export default {}
</script>