<template>
  <div class="content-block-title"><slot></slot></div>
</template>
<script>
  export default {}
</script>