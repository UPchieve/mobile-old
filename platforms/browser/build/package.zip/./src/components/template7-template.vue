<script>
  export default {
    render: function (c) {
        return c('script', {attrs: {type:'text/template7'}}, this.$slots.default)
    }
  }
</script>