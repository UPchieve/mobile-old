<template>
    <div class="login-screen-title"><slot></slot></div>
</template>
<script>
  export default {}
</script>