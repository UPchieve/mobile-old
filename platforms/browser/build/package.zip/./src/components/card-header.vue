<template>
  <div class="card-header">
    <slot></slot>
  </div>
</template>
<script>
  export default {}
</script>