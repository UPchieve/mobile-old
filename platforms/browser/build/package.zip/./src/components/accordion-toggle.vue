<template>
  <div class="accordion-item-toggle">
    <slot></slot>
  </div>
</template>
<script>
  export default {}
</script>