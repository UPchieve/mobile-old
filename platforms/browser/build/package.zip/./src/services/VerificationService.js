export default {
  sendVerification(){

  },

  confirmVerification(){

  }

}
